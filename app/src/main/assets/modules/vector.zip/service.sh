# GhostLock's root finisher starts the daemon after the zygote restart.
# During a managed late-load, skip the module's own service stage.
[ -f /data/adb/ghostlock-vector-managed ] && exit 0
[ -f /data/local/tmp/.ghostlock_vector_managed ] && exit 0

# Extract the directory path and change directory 
MODDIR="${0%/*}"
cd "$MODDIR" || exit 1

# Start the daemon directly in the background within a private mount namespace
unshare --propagation slave -m "$MODDIR/daemon" --system-server-max-retry=3 "$@" &
